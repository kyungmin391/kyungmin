#include <fstream>

#include "page.h"

using std::endl;
using std::ofstream;

class Board {
    public:
        Board(int num_jobs, int width, int height, ofstream& output_stream);
        ~Board(); //destructor

        void print_board();
        void print_job(int job_idx, char job_type, int id);

        Page find_page(int target) ; // find page using id
        bool overlap(Page, Page) ; // judge overlapping

        //job functions
        void insert_page(int x, int y, int width, int height, int id, int content);
        void delete_page(int id);
        void modify_content(int id, char content);
        void modify_position(int id, int x, int y);

    private:
        int num_jobs, width, height; 
        ofstream& output; 
        char* board; // 1D
        Page *pages ; // dynamic array of entire pages
        int p_index ;
};


Board::Board(int num_jobs, int width, int height, ofstream& output_stream): output(output_stream) {
    this->width = width; // derefernce+attribute
    this->height = height;
    this->num_jobs = num_jobs;

    board = new char[width*height]; // attribute

    for (int h = 0; h < height; h++) {
        for (int w = 0; w < width; w++) {
            board[h*width + w] = ' ';
        }
    }

    pages = new Page[num_jobs] ;
    p_index = 0 ;
}

Board::~Board() {
    delete board;
    
}


void Board::print_board() { // print board element
    int h, w;
    for (w = 0; w < width+2; w++) output << "- ";
    output << endl;
    
    for (h = 0; h < height; h++) {
        output << "| ";
        for (w = 0; w < width; w++) {
            output << board[h*width + w] << " ";
        }
        output << "| " << endl;
    }

    for (w = 0; w < width+2; w++) output << "- ";
    output << endl;
}

void Board::print_job(int job_idx, char job_type, int id) { // show job
    switch(job_type) {
        
        case 'i':
            output << "Insert ";
            break;
        case 'd':
            output << "Delete ";
            break;
        case 'm':
            output << "Modify ";
            break;
    }

    output << id << endl;
}

Page Board::find_page(int target) // search id from the last element
{
    for (int i=num_jobs; i>0; i--)
    {
        if (pages[i-1].get_id() == target)
        {
            return pages[i-1] ;
        }
    }
}

bool Board::overlap(Page page1, Page page2)
{
    // overlap boundary
    int left = (page1.get_x() < page2.get_x()) ? page1.get_x() : page2.get_x() ;
    int right = (page1.get_x()+page1.get_width() > page2.get_x()+page2.get_width()) ?
                 page1.get_x()+page1.get_width() : page2.get_x()+page2.get_width() ;
    int up = (page1.get_y() < page2.get_y()) ? page1.get_y() : page2.get_y() ;
    int down = (page1.get_y()+page1.get_height() > page2.get_y()+page2.get_height()) ?
                page1.get_y()+page1.get_height() : page2.get_y()+page2.get_height() ;

    if ((down-up < page1.get_height()+page2.get_height()-1) && (right-left < page1.get_width()+page2.get_width()-1))
    {
        return true ;
    }
    else
    {
        return false ;
    }
}

void Board::insert_page(int x, int y, int width, int height, int id, int content) {
    Page page = Page(x,y,width,height,id,content) ;
    pages[p_index] = page ; // save page info
    p_index += 1 ;

    int start = x + (this->width)*y ;
    for (int i=0; i<height, i++) // insertion
    {
        for (int j=0; j<width, j++)
        {
            board[start + i*(this->width) + j] = content ;
        }
    }
}

void Board::delete_page(int id) {
    
}

void Board::modify_content(int id, char content) { // remove and re-insert
   
}

void Board::modify_position(int id, int x, int y) {
     
}
