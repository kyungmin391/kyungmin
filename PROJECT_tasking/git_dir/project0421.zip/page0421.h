class Page {
    public:
        Page (int x, int y, int width, int height, int id, char content) ; // constructor
        int get_id () ; // accessor(getter)
        int get_X() ;
        int get_y() ;
        int get_width() ;
        int get_height() ;
        int get_content() ;

    private:
        int x, y; // position of the page on the board
        int width, height; // width and height of the page 
        int id; // unique id for each page
        char content; 
};

int Page::get_id(){return id ;}
int Page::get_x(){return x ;}
int Page::get_y(){return y ;}
int Page::get_width(){return width ;}
int Page::get_height(){return height ;}
int Page::get_content(){return content ;}
